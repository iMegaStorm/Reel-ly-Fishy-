﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishData : MonoBehaviour
{

    //[Header("Fish Data")]
    //public int value;
    ////public SpriteRenderer sprite;
    //public SpriteRenderer sprite;

    //[Header("Components")]
    //private Shop shop;

    //private void Start()
    //{
    //    shop = FindObjectOfType<Shop>();
    //    //sprite = GetComponent<SpriteRenderer>();
    //    sprite = GetComponent<SpriteRenderer>();
    //    //Debug.Log("Start: " + sprite);
    //}

    //public void GiveGold (int goldToGive)
    //{
    //    // Takes the current value of the fish and adds it to the variable goldToGive
    //    value += goldToGive;
    //    //Debug.Log("FishData: " + value);

    //    // Sends that data over to the inventory script
    //    //Inventory.instance.UpdateFishWorth(value);
    //}

    //public void GiveSprite (SpriteRenderer spriteToGive)
    //{
    //    sprite = spriteToGive;

    //    Debug.Log("FishData: " + sprite);
    //    //Debug.Log("FishData: " + spriteToGive);

    //    shop.UpdateShopData(sprite);
    //}
}
